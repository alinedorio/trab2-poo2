using MySql.Data.MySqlClient;

public class Database
{
    private static Database _instance;
    private MySqlConnection _connection;

    private Database()
    {
        string connectionString = "Server=localhost;Database=biblioteca;Uid=root;Pwd=senha;";
        _connection = new MySqlConnection(connectionString);
    }

    public static Database Instance
    {
        get
        {
            if (_instance == null)
                _instance = new Database();
            return _instance;
        }
    }

    public MySqlConnection Connection
    {
        get { return _connection; }
    }
}