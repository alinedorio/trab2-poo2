using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;

public class LivroRepository
{
    public List<string> ObterTodos()
    {
        List<string> livros = new List<string>();
        string query = "SELECT * FROM Livros";

        using (var command = new MySqlCommand(query, Database.Instance.Connection))
        {
            Database.Instance.Connection.Open();
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    livros.Add($"{reader["Titulo"]} por {reader["Autor"]}");
                }
            }
            Database.Instance.Connection.Close();
        }

        return livros;
    }

    public void Adicionar(string titulo, string autor, DateTime publicacao)
    {
        string query = "INSERT INTO Livros (Titulo, Autor, Publicacao) VALUES (@Titulo, @Autor, @Publicacao)";

        using (var command = new MySqlCommand(query, Database.Instance.Connection))
        {
            command.Parameters.AddWithValue("@Titulo", titulo);
            command.Parameters.AddWithValue("@Autor", autor);
            command.Parameters.AddWithValue("@Publicacao", publicacao);

            Database.Instance.Connection.Open();
            command.ExecuteNonQuery();
            Database.Instance.Connection.Close();
        }
    }
}